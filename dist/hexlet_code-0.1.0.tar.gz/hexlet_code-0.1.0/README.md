### Hexlet tests and linter status:
[![Actions Status](https://github.com/N-Davie/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/N-Davie/python-project-49/actions)
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=N-Davie_python-project-49&metric=alert_status)](https://sonarcloud.io/summary/new_code?id=N-Davie_python-project-49)
[Asciinema:even](https://asciinema.org/a/SaZ9m1nq32yDmzYbyuJIh4ECn)
[Asciinema:calc](https://asciinema.org/a/6CR98KTjyRwyWhnGPCLL26hmK)
[Asciinema:gcd](https://asciinema.org/a/QAeQASP9Hs85PNOavLPRptCNc)
[Asciinema:progression](https://asciinema.org/a/DHC6HOJphllaaV8GnWfQBn2JK)
[Asciinema:gcd](https://asciinema.org/a/QAeQASP9Hs85PNOavLPRptCNc)
[Asciinema:prime](https://asciinema.org/a/N5n7p680gomqs6Q2AX1UFCD81)
