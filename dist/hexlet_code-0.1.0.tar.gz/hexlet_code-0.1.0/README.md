### Hexlet tests and linter status:
[![Actions Status](https://github.com/N-Davie/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/N-Davie/python-project-49/actions)
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=N-Davie_python-project-49&metric=alert_status)](https://sonarcloud.io/summary/new_code?id=N-Davie_python-project-49)
[Asciinema](https://asciinema.org/a/kmH6Zjy5HlpEMI5i7vAzaWkv2)
