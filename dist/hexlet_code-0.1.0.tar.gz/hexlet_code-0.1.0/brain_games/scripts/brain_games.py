from brain_games.cli import welcome_user

def main():
    welcome_user()
    # здесь может быть остальной код игры

if __name__ == "__main__":
    main()
